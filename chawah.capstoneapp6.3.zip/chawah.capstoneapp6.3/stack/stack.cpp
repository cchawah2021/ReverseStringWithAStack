

#include <iostream>
#include <string>
using namespace std;

class Stack {
private:
	struct Node {
		std::string data;
		Node* next;

		Node(std::string data) : data(data), next(nullptr) {}
	};

	Node* top;

public:
	Stack() : top(nullptr) {}

	~Stack() {
		while (!isEmpty()) {
			pop();
		}
	}

	void push(std::string data) {
		std::reverse(data.begin(), data.end()); // Reverse the string
		Node* newNode = new Node(data);
		newNode->next = top;
		top = newNode;
		std::cout << "Pushed " << data << " to the stack." << std::endl;
	}

	std::string pop() {
		if (isEmpty()) {
			std::cout << "Stack is empty. Cannot pop." << std::endl;
			return ""; // Return an empty string indicating failure
		}
		std::string popped = top->data;
		Node* temp = top;
		top = top->next;
		delete temp;
		std::cout << "Popped " << popped << " from the stack." << std::endl;
		return popped;
	}

	std::string peek() {
		if (isEmpty()) {
			std::cout << "Stack is empty. Cannot peek." << std::endl;
			return ""; // Return an empty string indicating failure
		}
		return top->data;
	}

	bool isEmpty() {
		return top == null_ptr;
	}
};

int main() {
	Stack stack;
	stack.push("hello");
	stack.push("world");
	std::cout << "Top of stack: " << stack.peek() << std::endl;
	stack.pop();
	stack.pop();
	return 0;
}
